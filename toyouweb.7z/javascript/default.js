/*상단 메뉴 header*/
$(function(){
    var header = $('#menu_top'); //헤더를 변수에 넣기
    var page = $('#menu_top'); //색상이 변할 부분
    var pageOffsetTop = page.offset().top; //색상 변할 부분의 top값 구하기
    $(window).resize(function(){ //반응형을 대비하여 리사이즈시 top값을 다시 계산
      pageOffsetTop = page.offset().top;
    });
    
    $(window).on('scroll', function(){
      if($(window).scrollTop() > pageOffsetTop) { // 스크롤이 page보다 밑에 내려가면
        header.addClass('on'); //클래스 추가
      }else { // 스크롤 올릴 때
        header.removeClass('on'); //클래스 제거
      }
    });
  });

  


/* 사이드 메뉴 : right */
$(function(){ //사이드 메뉴 열 때,
  $("#menu_top .right_menu").click(function(){
      $(".side_menu").css("right","0px");
      $(".side_menu").css("transition","0.5s");
  })
});
$(function(){ //사이드 메뉴 닫을 때,
  $(".side_menu .close_btn").click(function(){
      $(".side_menu").css("right","-340px");
      $(".side_menu").css("transition","0.5s");
  })
});




/* 사이드 메뉴 : left */
$(window).scroll(function() {
  $(".left_quickMenu").stop().animate({ "top" : ($(window).scrollTop()) + "px" }, 500);
});





$(document).ready(function (){
  
  /* 메인 핸드폰 애니메이션 : main_bottom */
  phone_start();

  /* 메인 슬라이드  : main_right*/
  setInterval( function(){             //setInterval(); 함수 반복 실행 메소드
    $(".main_right .right_sub_wrap").delay("2500");        //2.5초 = 2500밀리초 정지
    $(".main_right .right_sub_wrap").animate({marginTop:  "-270px" },"6000");  //0.5초 동안 위쪽여백:-300px
    $(".main_right .right_sub_wrap").delay("2500");                           //2.5초 정지
    $(".main_right .right_sub_wrap").animate({marginTop:  "-540" },"6000");  //0.5초 동안 위쪽여백:-600px
    $(".main_right .right_sub_wrap").delay("2500");                           //2.5초 정지
    $(".main_right .right_sub_wrap").animate({marginTop:  "-810" },"6000");  //0.5초 동안 위쪽여백:-600px
    $(".main_right .right_sub_wrap").delay("2500");    
    $(".main_right .right_sub_wrap").animate({marginTop:  "0" },"6000");       //위쪽여백:0px 처음위치로
  });

  
  /*메인 슬라이드 : main_left */
  var main_right_slide = $('.main_left .slide_contents .main_left_slide').length-1; //슬라이드 이미지 개수 
  var img = main_right_slide; //이미지 갯수 : 0부터 시작 
  var now = img; //현재 이미지 슬라이드 (번호) : 0번부터 시작 

  $('.slide_contents a').eq(0).siblings().hide();
  function slide(){
    if (now == img){
      $('.slide_contents a').eq(now).fadeOut(250);
      $('.slide_contents a').eq(0).fadeIn(250);
      now = 0;
    }
    else{
      $('.slide_contents a').eq(now).fadeOut(250);
      $('.slide_contents a').eq(now+1).fadeIn(250);
      now++;
    }
  }
  setInterval(slide, 5000);




});


/* 메인 핸드폰 애니메이션 : main_bottom */
function phone_start(){ //애니메이션 동작
  $(".main_bottom .img_box").animate({ "margin-top" :"-550px" , "opacity" : 0}, 6000);
  $(".main_bottom .img_box").animate({ "margin-top" :"-75px" , "opacity" : 1}, 0);
}

setInterval(phone_start,6000);










